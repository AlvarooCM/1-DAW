"""
 Escribe un script que pida ao usuario o seu nome e apelidos por separado e mostra a seguinte mensaxe por pantalla: O usuario <apelido1> <apelido 2>, <nome> rexistrouse correctamente
"""

__author__ ="Alvaro Camino Martinez"

#Pedimos que ingrese los datos

nome = input("Introduce o teu nome: ")

apelido1 = input("Introduce o teu primeiro apelido: ")

apelido2 = input("Introduce o teu segundo apelido: ")

#Imprimimos la solucion

print(f"O usuario {apelido1} {apelido2}, {nome} rexistrouse correctamente.")


